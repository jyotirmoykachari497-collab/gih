package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.RecordedClip
import com.example.model.RecordingState
import com.example.security.AuthLaunchResult
import com.example.security.BiometricStopAuthenticator
import com.example.ui.screens.GuardScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.theme.LocalSentinelColors
import com.example.ui.theme.SentinelCamTheme
import com.example.viewmodel.SafetyViewModel
import java.io.File

private enum class SentinelTab(val labelRes: Int) {
    GUARD(R.string.tab_guard),
    VAULT(R.string.tab_vault)
}

class MainActivity : FragmentActivity() {

    private var safetyViewModel: SafetyViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val vm: SafetyViewModel = viewModel()
            safetyViewModel = vm
            SentinelCamTheme(darkTheme = true) {
                SentinelAppRoot(
                    activity = this@MainActivity,
                    viewModel = vm
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        safetyViewModel?.refreshEnvironment(this)
    }

    override fun onStop() {
        super.onStop()
        // Immediately lock Stop & Save whenever the user leaves the foreground or turns off screen
        safetyViewModel?.revokeStopUnlockOnBackground()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SentinelAppRoot(
    activity: FragmentActivity,
    viewModel: SafetyViewModel
) {
    val context = LocalContext.current
    val recordingState by viewModel.recordingState.collectAsStateWithLifecycle()
    val cameraReadiness by viewModel.cameraReadiness.collectAsStateWithLifecycle()
    val selectedMode by viewModel.selectedMode.collectAsStateWithLifecycle()
    val permissionStatus by viewModel.permissionStatus.collectAsStateWithLifecycle()
    val isStopAuthorized by viewModel.isStopAuthorized.collectAsStateWithLifecycle()
    val stopAuthCountdown by viewModel.stopAuthCountdown.collectAsStateWithLifecycle()
    val statusBannerMessage by viewModel.statusBannerMessage.collectAsStateWithLifecycle()
    val savedClips by viewModel.savedClips.collectAsStateWithLifecycle()
    val diagnosticEvents by viewModel.diagnosticEvents.collectAsStateWithLifecycle()
    val stealthModeEnabled by viewModel.stealthModeEnabled.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(SentinelTab.GUARD) }
    var showPermissionRationaleDialog by remember { mutableStateOf(false) }
    var showNoDeviceLockDialog by remember { mutableStateOf(false) }
    var pendingStartAfterPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        viewModel.updatePermissions(context)
        val updated = viewModel.permissionStatus.value
        if (updated.cameraGranted && updated.audioGranted) {
            if (pendingStartAfterPermission) {
                pendingStartAfterPermission = false
                viewModel.startEmergencyRecording(context)
            }
        } else {
            pendingStartAfterPermission = false
            showPermissionRationaleDialog = true
        }
    }

    val confirmDeviceCredentialLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == FragmentActivity.RESULT_OK) {
            viewModel.onAuthenticationSucceeded()
        } else {
            viewModel.onAuthenticationError("Device credential verification cancelled.")
        }
    }

    val triggerUnlockToStop = {
        when (
            val authResult = BiometricStopAuthenticator.authenticateToStop(
                activity = activity,
                onSuccess = { viewModel.onAuthenticationSucceeded() },
                onFailure = { msg -> viewModel.onAuthenticationError(msg) }
            )
        ) {
            AuthLaunchResult.BiometricPromptLaunched -> Unit
            is AuthLaunchResult.ConfirmDeviceCredentialIntent -> {
                confirmDeviceCredentialLauncher.launch(authResult.intent)
            }
            AuthLaunchResult.NoDeviceLockConfigured -> {
                showNoDeviceLockDialog = true
            }
            is AuthLaunchResult.Error -> Unit
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideScreen = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_sentinel_logo_1794850234099),
                                    contentDescription = "SentinelCam Emblem",
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleLarge
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background,
                            titleContentColor = MaterialTheme.colorScheme.onBackground
                        )
                    )
                },
                bottomBar = {
                    if (!isWideScreen) {
                        NavigationBar(
                            modifier = Modifier.navigationBarsPadding(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            SentinelTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                                    icon = {
                                        TabIcon(
                                            tab = tab,
                                            selected = selected,
                                            clipCount = savedClips.size
                                        )
                                    },
                                    label = { Text(stringResource(tab.labelRes)) }
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isWideScreen) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            Spacer(Modifier.size(16.dp))
                            SentinelTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}"),
                                    icon = {
                                        TabIcon(
                                            tab = tab,
                                            selected = selected,
                                            clipCount = savedClips.size
                                        )
                                    },
                                    label = { Text(stringResource(tab.labelRes)) }
                                )
                            }
                        }
                    }

                    when (currentTab) {
                        SentinelTab.GUARD -> {
                            GuardScreen(
                                isWideScreen = isWideScreen,
                                recordingState = recordingState,
                                cameraReadiness = cameraReadiness,
                                selectedMode = selectedMode,
                                permissionStatus = permissionStatus,
                                isStopAuthorized = isStopAuthorized,
                                stopAuthCountdown = stopAuthCountdown,
                                statusBannerMessage = statusBannerMessage,
                                onSelectMode = { viewModel.selectCameraMode(it) },
                                onStartRecording = {
                                    if (permissionStatus.cameraGranted && permissionStatus.audioGranted) {
                                        viewModel.startEmergencyRecording(context)
                                    } else {
                                        pendingStartAfterPermission = true
                                        permissionLauncher.launch(viewModel.requiredRuntimePermissions())
                                    }
                                },
                                onRequestPermissions = {
                                    pendingStartAfterPermission = false
                                    permissionLauncher.launch(viewModel.requiredRuntimePermissions())
                                },
                                onUnlockStopClick = triggerUnlockToStop,
                                onStopAndSaveClick = {
                                    viewModel.triggerAuthenticatedStopAndSave(context)
                                },
                                onEnableStealthClick = { viewModel.toggleStealthMode(true) },
                                onDismissBanner = { viewModel.dismissBanner() }
                            )
                        }

                        SentinelTab.VAULT -> {
                            VaultScreen(
                                isWideScreen = isWideScreen,
                                savedClips = savedClips,
                                diagnosticEvents = diagnosticEvents,
                                onRefresh = { viewModel.refreshClips(context) },
                                onPlayClip = { clip -> openClipAction(context, clip, isShare = false) },
                                onShareClip = { clip -> openClipAction(context, clip, isShare = true) },
                                onDeleteClip = { clip -> viewModel.deleteClip(context, clip) }
                            )
                        }
                    }
                }
            }
        }

        // Covert OLED Blackout Overlay while recording (double-tap to restore UI controls)
        if (stealthModeEnabled && recordingState is RecordingState.Recording) {
            StealthBlackoutOverlay(
                onRestore = { viewModel.toggleStealthMode(false) }
            )
        }
    }

    if (showPermissionRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionRationaleDialog = false },
            title = { Text(stringResource(R.string.permission_dialog_title)) },
            text = { Text(stringResource(R.string.permission_denied_settings)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showPermissionRationaleDialog = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    }
                ) {
                    Text("Open Settings")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPermissionRationaleDialog = false
                        permissionLauncher.launch(viewModel.requiredRuntimePermissions())
                    }
                ) {
                    Text("Retry")
                }
            }
        )
    }

    if (showNoDeviceLockDialog) {
        AlertDialog(
            onDismissRequest = { showNoDeviceLockDialog = false },
            title = { Text("No Device Lock Configured") },
            text = {
                Text(
                    "This device has no Fingerprint, Face Unlock, PIN, or Pattern enrolled. " +
                        "Set up a device screen lock in Android Security Settings for tamper-proof protection, " +
                        "or confirm below to arm Stop & Save on this unsecured device."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showNoDeviceLockDialog = false
                        viewModel.onAuthenticationSucceeded()
                    },
                    modifier = Modifier.testTag("confirm_unsecured_unlock_button")
                ) {
                    Text("Arm Stop & Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showNoDeviceLockDialog = false
                        runCatching {
                            context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                        }
                    }
                ) {
                    Text("Security Settings")
                }
            }
        )
    }
}

@Composable
private fun TabIcon(
    tab: SentinelTab,
    selected: Boolean,
    clipCount: Int
) {
    when (tab) {
        SentinelTab.GUARD -> Icon(
            imageVector = if (selected) Icons.Filled.Shield else Icons.Outlined.Shield,
            contentDescription = stringResource(tab.labelRes)
        )
        SentinelTab.VAULT -> BadgedBox(
            badge = {
                if (clipCount > 0) {
                    Badge { Text("$clipCount") }
                }
            }
        ) {
            Icon(
                imageVector = if (selected) Icons.Filled.Folder else Icons.Outlined.Folder,
                contentDescription = stringResource(tab.labelRes)
            )
        }
    }
}

@Composable
private fun StealthBlackoutOverlay(onRestore: () -> Unit) {
    var tapCount by remember { mutableIntStateOf(0) }
    val sentinelColors = LocalSentinelColors.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(sentinelColors.stealthSurface)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                tapCount += 1
                if (tapCount >= 2) {
                    tapCount = 0
                    onRestore()
                }
            }
            .testTag("stealth_blackout_overlay"),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "Stealth Active • Recording Protected",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.28f)
            )
            Text(
                text = "Double-tap anywhere to show controls",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.22f)
            )
        }
    }
}

private fun openClipAction(context: android.content.Context, clip: RecordedClip, isShare: Boolean) {
    val file = File(clip.filePath)
    if (!file.exists()) return
    val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
    )
    val intent = if (isShare) {
        Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    } else {
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
    runCatching {
        context.startActivity(
            Intent.createChooser(intent, if (isShare) "Share Evidence Clip" else "Play Evidence Clip")
        )
    }
}
