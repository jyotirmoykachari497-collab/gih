package com.example.camera

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import android.util.Size
import com.example.model.CameraReadiness

/**
 * Inspects Camera2 hardware capabilities, including lens facing IDs, optimal MediaRecorder
 * video resolutions, sensor orientation hints, and Android 11+ concurrent camera combinations.
 */
object CameraCapabilityInspector {

    private const val TAG = "CameraCapability"

    fun inspect(context: Context): CameraReadiness {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return CameraReadiness(hardwareSummary = "CameraManager unavailable on this device")

        return try {
            var rearId: String? = null
            var frontId: String? = null
            val facingById = mutableMapOf<String, Int>()

            for (id in manager.cameraIdList) {
                val characteristics = manager.getCameraCharacteristics(id)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING) ?: continue
                facingById[id] = facing
                if (facing == CameraCharacteristics.LENS_FACING_BACK && rearId == null) {
                    rearId = id
                } else if (facing == CameraCharacteristics.LENS_FACING_FRONT && frontId == null) {
                    frontId = id
                }
            }

            var concurrentPair: Pair<String, String>? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val combinations = manager.concurrentCameraIds
                for (combo in combinations) {
                    val backInCombo = combo.firstOrNull { facingById[it] == CameraCharacteristics.LENS_FACING_BACK }
                    val frontInCombo = combo.firstOrNull { facingById[it] == CameraCharacteristics.LENS_FACING_FRONT }
                    if (backInCombo != null && frontInCombo != null) {
                        concurrentPair = backInCombo to frontInCombo
                        break
                    }
                }
            }

            val summary = buildString {
                append(if (rearId != null) "Rear #$rearId Ready" else "No Rear Camera")
                append(" • ")
                append(if (frontId != null) "Front #$frontId Ready" else "No Front Camera")
                append(" • ")
                append(
                    if (concurrentPair != null) {
                        "Concurrent Dual Supported"
                    } else {
                        "Single-Stream ISP (Rear Fallback)"
                    }
                )
            }

            CameraReadiness(
                hasRearCamera = rearId != null,
                rearCameraId = rearId,
                hasFrontCamera = frontId != null,
                frontCameraId = frontId,
                supportsConcurrentDual = concurrentPair != null,
                concurrentPair = concurrentPair,
                hardwareSummary = summary
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to inspect Camera2 capabilities", e)
            CameraReadiness(hardwareSummary = "Camera inspection error: ${e.message ?: "Unknown"}")
        }
    }

    /**
     * Selects a reliable 16:9 video resolution supported by [MediaRecorder] for the given camera.
     * In concurrent dual mode, prefers 1280x720 to stay well within hardware ISP bandwidth limits.
     */
    fun selectOptimalVideoSize(
        manager: CameraManager,
        cameraId: String,
        prefer720p: Boolean
    ): Size {
        val targetMaxWidth = if (prefer720p) 1280 else 1920
        val targetMaxHeight = if (prefer720p) 720 else 1080
        return try {
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(MediaRecorder::class.java).orEmpty()
            val candidates = sizes
                .filter { it.width <= targetMaxWidth && it.height <= targetMaxHeight }
                .sortedWith(
                    compareByDescending<Size> { it.width * it.height }
                        .thenByDescending { it.width }
                )
            // Prefer exact 16:9 or closest standard resolution
            candidates.firstOrNull { it.width * 9 == it.height * 16 }
                ?: candidates.firstOrNull()
                ?: Size(1280, 720)
        } catch (e: Exception) {
            Log.w(TAG, "Unable to query output sizes for camera $cameraId; defaulting to 1280x720", e)
            Size(1280, 720)
        }
    }

    /**
     * Returns a MediaRecorder orientation hint matching the physical camera sensor orientation.
     */
    fun getSensorOrientationHint(manager: CameraManager, cameraId: String): Int {
        return try {
            val characteristics = manager.getCameraCharacteristics(cameraId)
            characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        } catch (_: Exception) {
            90
        }
    }
}
