package com.example.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Environment
import com.example.model.CameraReadiness
import com.example.model.DiagnosticEvent
import com.example.model.EventLevel
import com.example.model.RecordedClip
import com.example.model.RecordingState
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

/**
 * Process-wide state bridge connecting SafetyRecordingService, MainActivity, and SafetyViewModel.
 * Holds live recording status, biometric stop-unlock authorization, diagnostics, and Vault files.
 */
object RecordingRepository {

    private const val MAX_LOG_ENTRIES = 120
    private val eventIdGen = AtomicLong(1L)

    private val _recordingState = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

    private val _cameraReadiness = MutableStateFlow(CameraReadiness())
    val cameraReadiness: StateFlow<CameraReadiness> = _cameraReadiness.asStateFlow()

    private val _diagnosticEvents = MutableStateFlow<List<DiagnosticEvent>>(emptyList())
    val diagnosticEvents: StateFlow<List<DiagnosticEvent>> = _diagnosticEvents.asStateFlow()

    private val _savedClips = MutableStateFlow<List<RecordedClip>>(emptyList())
    val savedClips: StateFlow<List<RecordedClip>> = _savedClips.asStateFlow()

    private val _isStopAuthorized = MutableStateFlow(false)
    val isStopAuthorized: StateFlow<Boolean> = _isStopAuthorized.asStateFlow()

    fun updateRecordingState(state: RecordingState) {
        _recordingState.value = state
        if (state !is RecordingState.Recording) {
            _isStopAuthorized.value = false
        }
    }

    fun updateCameraReadiness(readiness: CameraReadiness) {
        _cameraReadiness.value = readiness
    }

    fun authorizeStop() {
        if (_recordingState.value is RecordingState.Recording) {
            _isStopAuthorized.value = true
            addDiagnostic(EventLevel.INFO, "Biometric/credential verification succeeded. Stop & Save armed.")
        }
    }

    fun revokeStopAuthorization(reason: String? = null) {
        if (_isStopAuthorized.value) {
            _isStopAuthorized.value = false
            if (!reason.isNullOrBlank()) {
                addDiagnostic(EventLevel.INFO, reason)
            }
        }
    }

    fun addDiagnostic(level: EventLevel, message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val event = DiagnosticEvent(
            id = eventIdGen.getAndIncrement(),
            timestamp = time,
            level = level,
            message = message
        )
        _diagnosticEvents.update { current ->
            (listOf(event) + current).take(MAX_LOG_ENTRIES)
        }
    }

    fun recordingsDirectory(context: Context): File {
        val baseDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        return File(baseDir, "SentinelCam").apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }

    fun createOutputFile(context: Context, timestampTag: String, suffix: String = ""): File {
        val name = if (suffix.isBlank()) {
            "SafetyRec_$timestampTag.mp4"
        } else {
            "SafetyRec_${timestampTag}_$suffix.mp4"
        }
        return File(recordingsDirectory(context), name)
    }

    suspend fun refreshSavedClips(context: Context) = withContext(Dispatchers.IO) {
        val dir = recordingsDirectory(context)
        val activeFiles = when (val state = _recordingState.value) {
            is RecordingState.Recording -> setOfNotNull(
                state.session.primaryFileName,
                state.session.secondaryFileName
            )
            else -> emptySet()
        }

        val files = dir.listFiles { file ->
            file.isFile &&
                file.name.endsWith(".mp4", ignoreCase = true) &&
                file.length() > 0L &&
                !activeFiles.contains(file.name)
        }?.sortedByDescending { it.lastModified() }.orEmpty()

        val clips = files.map { file ->
            val durationMs = extractDurationMs(file)
            val cameraTag = when {
                file.name.contains("_REAR", ignoreCase = true) -> "REAR"
                file.name.contains("_FRONT", ignoreCase = true) -> "FRONT"
                else -> "PRIMARY"
            }
            RecordedClip(
                id = file.absolutePath,
                fileName = file.name,
                filePath = file.absolutePath,
                sizeBytes = file.length(),
                durationMs = durationMs,
                timestampMs = file.lastModified(),
                cameraTag = cameraTag
            )
        }
        _savedClips.value = clips
    }

    suspend fun deleteClip(context: Context, clip: RecordedClip): Boolean = withContext(Dispatchers.IO) {
        val deleted = runCatching { File(clip.filePath).delete() }.getOrDefault(false)
        if (deleted) {
            addDiagnostic(EventLevel.INFO, "Deleted clip ${clip.fileName}")
            refreshSavedClips(context)
        }
        deleted
    }

    private fun extractDurationMs(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }
}
