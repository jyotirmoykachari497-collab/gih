package com.example.model

enum class CameraSelectionMode(val label: String, val shortLabel: String) {
    CONCURRENT_DUAL("Dual (Front + Rear)", "Dual"),
    REAR_ONLY("Primary Rear Camera", "Rear"),
    FRONT_ONLY("Front Camera", "Front")
}

data class CameraReadiness(
    val hasRearCamera: Boolean = false,
    val rearCameraId: String? = null,
    val hasFrontCamera: Boolean = false,
    val frontCameraId: String? = null,
    val supportsConcurrentDual: Boolean = false,
    val concurrentPair: Pair<String, String>? = null,
    val hardwareSummary: String = "Inspecting camera hardware..."
) {
    val isAnyCameraAvailable: Boolean
        get() = hasRearCamera || hasFrontCamera

    fun isModeReady(mode: CameraSelectionMode): Boolean = when (mode) {
        CameraSelectionMode.CONCURRENT_DUAL -> isAnyCameraAvailable // Graceful fallback to rear
        CameraSelectionMode.REAR_ONLY -> hasRearCamera
        CameraSelectionMode.FRONT_ONLY -> hasFrontCamera
    }
}

data class ActiveSessionInfo(
    val modeRequested: CameraSelectionMode,
    val activeMode: CameraSelectionMode,
    val isDualActive: Boolean,
    val fallbackReason: String? = null,
    val elapsedSeconds: Long = 0L,
    val primaryFileName: String,
    val secondaryFileName: String? = null,
    val recoveryCount: Int = 0,
    val isWakeLockHeld: Boolean = false,
    val screenOffContinuityVerified: Boolean = false,
    val statusMessage: String = "Capturing video and audio"
)

sealed interface RecordingState {
    data object Idle : RecordingState
    data class Starting(val mode: CameraSelectionMode) : RecordingState
    data class Recording(val session: ActiveSessionInfo) : RecordingState
    data object Stopping : RecordingState
    data class Error(val message: String, val recoverable: Boolean = true) : RecordingState
}

data class RecordedClip(
    val id: String,
    val fileName: String,
    val filePath: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val timestampMs: Long,
    val cameraTag: String
)

enum class EventLevel {
    INFO,
    WARN,
    ERROR
}

data class DiagnosticEvent(
    val id: Long,
    val timestamp: String,
    val level: EventLevel,
    val message: String
)

data class PermissionStatus(
    val cameraGranted: Boolean = false,
    val audioGranted: Boolean = false,
    val notificationsGranted: Boolean = false
) {
    val allRequiredGranted: Boolean
        get() = cameraGranted && audioGranted && notificationsGranted
}
