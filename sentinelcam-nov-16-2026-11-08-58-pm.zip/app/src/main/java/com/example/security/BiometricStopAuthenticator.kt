package com.example.security

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.R

sealed interface AuthLaunchResult {
    data object BiometricPromptLaunched : AuthLaunchResult
    data class ConfirmDeviceCredentialIntent(val intent: Intent) : AuthLaunchResult
    data object NoDeviceLockConfigured : AuthLaunchResult
    data class Error(val message: String) : AuthLaunchResult
}

/**
 * Enforces biometric (Fingerprint / FaceUnlock) or Device Credential (PIN / Pattern / Password)
 * verification before permitting the active safety recording to be stopped.
 */
object BiometricStopAuthenticator {

    private val allowedAuthenticators: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            @Suppress("DEPRECATION")
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        }

    fun isDeviceSecured(context: Context): Boolean {
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return keyguard?.isDeviceSecure == true
    }

    fun isDeviceCurrentlyLocked(context: Context): Boolean {
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return keyguard?.isKeyguardLocked == true
    }

    fun authenticateToStop(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ): AuthLaunchResult {
        if (isDeviceCurrentlyLocked(activity)) {
            val msg = "Unlock your phone first before stopping the recording."
            onFailure(msg)
            return AuthLaunchResult.Error(msg)
        }

        val biometricManager = BiometricManager.from(activity)
        val canAuth = biometricManager.canAuthenticate(allowedAuthenticators)

        if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
            val executor = ContextCompat.getMainExecutor(activity)
            val prompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(
                        result: BiometricPrompt.AuthenticationResult
                    ) {
                        super.onAuthenticationSucceeded(result)
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                            errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                            errorCode != BiometricPrompt.ERROR_CANCELED
                        ) {
                            onFailure(errString.toString())
                        }
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        onFailure("Authentication not recognized. Try again.")
                    }
                }
            )

            // Note: Do not call setNegativeButtonText when DEVICE_CREDENTIAL is included.
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle(activity.getString(R.string.biometric_prompt_title))
                .setSubtitle(activity.getString(R.string.biometric_prompt_subtitle))
                .setAllowedAuthenticators(allowedAuthenticators)
                .setConfirmationRequired(true)
                .build()

            prompt.authenticate(promptInfo)
            return AuthLaunchResult.BiometricPromptLaunched
        }

        // Fallback for API 24-29 where BiometricPrompt + DEVICE_CREDENTIAL may report unavailable
        // even when a device PIN/Pattern/Password is configured.
        val keyguard = activity.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (keyguard?.isDeviceSecure == true) {
            @Suppress("DEPRECATION")
            val intent = keyguard.createConfirmDeviceCredentialIntent(
                activity.getString(R.string.biometric_prompt_title),
                activity.getString(R.string.biometric_prompt_subtitle)
            )
            if (intent != null) {
                return AuthLaunchResult.ConfirmDeviceCredentialIntent(intent)
            }
        }

        return AuthLaunchResult.NoDeviceLockConfigured
    }
}
