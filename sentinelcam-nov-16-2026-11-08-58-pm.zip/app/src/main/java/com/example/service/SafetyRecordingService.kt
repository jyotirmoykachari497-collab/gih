package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.camera.CameraCapabilityInspector
import com.example.data.RecordingRepository
import com.example.model.ActiveSessionInfo
import com.example.model.CameraSelectionMode
import com.example.model.EventLevel
import com.example.model.RecordingState
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground Service powering screen-off Camera2 + MediaRecorder capture.
 *
 * Key resilience features:
 * - Acquires a PARTIAL_WAKE_LOCK to keep CPU and MediaRecorder pipelines active when screen is off.
 * - Routes Camera2 output directly to MediaRecorder.getSurface() with no UI SurfaceView required.
 * - Supports Android 11+ concurrent front + rear capture with automatic graceful fallback to rear
 *   if hardware ISP concurrency is unavailable or throws ERROR_MAX_CAMERAS_IN_USE.
 * - Recovers automatically from transient CameraDevice.StateCallback.onError interruptions.
 * - Cannot be stopped from the notification or locked screen; requires authenticated stop intent.
 */
class SafetyRecordingService : Service() {

    companion object {
        private const val TAG = "SafetyRecordingService"
        private const val NOTIFICATION_CHANNEL_ID = "sentinel_recording_channel"
        private const val NOTIFICATION_ID = 4109
        private const val MAX_RECOVERY_ATTEMPTS = 3

        const val ACTION_START_RECORDING = "com.example.action.START_RECORDING"
        const val ACTION_AUTHENTICATED_STOP = "com.example.action.AUTHENTICATED_STOP"
        const val EXTRA_CAMERA_MODE = "extra_camera_mode"

        fun createStartIntent(context: Context, mode: CameraSelectionMode): Intent {
            return Intent(context, SafetyRecordingService::class.java).apply {
                action = ACTION_START_RECORDING
                putExtra(EXTRA_CAMERA_MODE, mode.name)
            }
        }

        fun createAuthenticatedStopIntent(context: Context): Intent {
            return Intent(context, SafetyRecordingService::class.java).apply {
                action = ACTION_AUTHENTICATED_STOP
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var primaryPipeline: CameraPipeline? = null
    private var secondaryPipeline: CameraPipeline? = null

    private var tickerJob: Job? = null
    private var recoveryJob: Job? = null

    @Volatile
    private var isStopping = false

    @Volatile
    private var requestedMode: CameraSelectionMode = CameraSelectionMode.CONCURRENT_DUAL

    @Volatile
    private var recoveryCount = 0

    private var currentSessionInfo: ActiveSessionInfo? = null
    private var screenReceiverRegistered = false

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    RecordingRepository.revokeStopAuthorization(
                        "Screen locked/off — Stop control re-locked; background capture continuing."
                    )
                    RecordingRepository.addDiagnostic(
                        EventLevel.INFO,
                        "Screen OFF detected — WakeLock active, Camera2 surface streaming uninterrupted."
                    )
                    currentSessionInfo = currentSessionInfo?.copy(
                        screenOffContinuityVerified = true,
                        statusMessage = "Screen off — capturing covertly in background"
                    )
                    currentSessionInfo?.let {
                        RecordingRepository.updateRecordingState(RecordingState.Recording(it))
                    }
                }
                Intent.ACTION_USER_PRESENT -> {
                    RecordingRepository.addDiagnostic(
                        EventLevel.INFO,
                        "Device unlocked — open SentinelCam and authenticate to Stop & Save."
                    )
                    currentSessionInfo = currentSessionInfo?.copy(
                        statusMessage = "Device unlocked — biometric/PIN required to stop"
                    )
                    currentSessionInfo?.let {
                        RecordingRepository.updateRecordingState(RecordingState.Recording(it))
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel()
        startBackgroundThread()
        registerScreenReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_RECORDING -> {
                val modeName = intent.getStringExtra(EXTRA_CAMERA_MODE)
                val mode = CameraSelectionMode.entries.firstOrNull { it.name == modeName }
                    ?: CameraSelectionMode.CONCURRENT_DUAL
                startProtectedRecording(mode)
            }

            ACTION_AUTHENTICATED_STOP -> {
                if (!RecordingRepository.isStopAuthorized.value) {
                    Log.w(TAG, "Blocked unauthorized stop request.")
                    RecordingRepository.addDiagnostic(
                        EventLevel.WARN,
                        "Blocked unauthenticated stop attempt."
                    )
                    return START_STICKY
                }
                stopAndSaveRecording()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isStopping = true
        tickerJob?.cancel()
        recoveryJob?.cancel()
        releasePipelines()
        releaseWakeLock()
        unregisterScreenReceiver()
        stopBackgroundThread()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startProtectedRecording(mode: CameraSelectionMode) {
        if (RecordingRepository.recordingState.value is RecordingState.Recording ||
            RecordingRepository.recordingState.value is RecordingState.Starting
        ) {
            Log.d(TAG, "Recording already active; ignoring duplicate start.")
            return
        }

        if (!hasRequiredRuntimePermissions()) {
            val msg = "Missing Camera or Microphone permission."
            RecordingRepository.addDiagnostic(EventLevel.ERROR, msg)
            RecordingRepository.updateRecordingState(RecordingState.Error(msg, recoverable = true))
            stopSelf()
            return
        }

        isStopping = false
        requestedMode = mode
        recoveryCount = 0
        RecordingRepository.revokeStopAuthorization()
        RecordingRepository.updateRecordingState(RecordingState.Starting(mode))

        promoteToForeground("Initializing protected Camera2 pipeline...")
        acquireWakeLock()

        launchCaptureSession(mode = mode, isRecovery = false)
    }

    @SuppressLint("MissingPermission")
    private fun launchCaptureSession(mode: CameraSelectionMode, isRecovery: Boolean) {
        val manager = getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        if (manager == null) {
            failSession("CameraManager service unavailable.", recoverable = false)
            return
        }

        val readiness = CameraCapabilityInspector.inspect(this)
        RecordingRepository.updateCameraReadiness(readiness)

        if (!readiness.isAnyCameraAvailable) {
            failSession("No functional camera hardware detected on this device.", recoverable = false)
            return
        }

        val timestampTag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val recoverySuffix = if (isRecovery) "_R$recoveryCount" else ""

        // Resolve mode + hardware concurrent fallback
        var activeMode = mode
        var fallbackReason: String? = null
        var rearId: String? = readiness.rearCameraId
        var frontId: String? = readiness.frontCameraId

        if (mode == CameraSelectionMode.CONCURRENT_DUAL) {
            val concurrentPair = readiness.concurrentPair
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || concurrentPair == null) {
                activeMode = if (rearId != null) {
                    CameraSelectionMode.REAR_ONLY
                } else {
                    CameraSelectionMode.FRONT_ONLY
                }
                fallbackReason = "Concurrent dual-camera ISP not supported on this device; fell back to ${activeMode.shortLabel} camera."
                Log.w(TAG, fallbackReason)
                RecordingRepository.addDiagnostic(EventLevel.WARN, fallbackReason)
            } else {
                rearId = concurrentPair.first
                frontId = concurrentPair.second
            }
        } else if (mode == CameraSelectionMode.REAR_ONLY && rearId == null && frontId != null) {
            activeMode = CameraSelectionMode.FRONT_ONLY
            fallbackReason = "Primary rear camera unavailable; fell back to front camera."
            Log.w(TAG, fallbackReason)
            RecordingRepository.addDiagnostic(EventLevel.WARN, fallbackReason)
        } else if (mode == CameraSelectionMode.FRONT_ONLY && frontId == null && rearId != null) {
            activeMode = CameraSelectionMode.REAR_ONLY
            fallbackReason = "Front camera unavailable; fell back to primary rear camera."
            Log.w(TAG, fallbackReason)
            RecordingRepository.addDiagnostic(EventLevel.WARN, fallbackReason)
        }

        val isDualAttempt = activeMode == CameraSelectionMode.CONCURRENT_DUAL &&
            rearId != null && frontId != null

        val primaryCameraId = when (activeMode) {
            CameraSelectionMode.CONCURRENT_DUAL -> rearId!!
            CameraSelectionMode.REAR_ONLY -> rearId ?: frontId!!
            CameraSelectionMode.FRONT_ONLY -> frontId ?: rearId!!
        }

        val primarySuffix = when {
            isDualAttempt -> "REAR$recoverySuffix"
            else -> recoverySuffix.removePrefix("_")
        }
        val primaryFile = RecordingRepository.createOutputFile(this, timestampTag, primarySuffix)
        val secondaryFile = if (isDualAttempt) {
            RecordingRepository.createOutputFile(this, timestampTag, "FRONT$recoverySuffix")
        } else {
            null
        }

        val sessionInfo = ActiveSessionInfo(
            modeRequested = mode,
            activeMode = activeMode,
            isDualActive = isDualAttempt,
            fallbackReason = fallbackReason,
            elapsedSeconds = currentSessionInfo?.elapsedSeconds ?: 0L,
            primaryFileName = primaryFile.name,
            secondaryFileName = secondaryFile?.name,
            recoveryCount = recoveryCount,
            isWakeLockHeld = wakeLock?.isHeld == true,
            screenOffContinuityVerified = currentSessionInfo?.screenOffContinuityVerified ?: false,
            statusMessage = if (isDualAttempt) {
                "Dual concurrent video + audio capture active"
            } else {
                "Background video + audio capture active"
            }
        )
        currentSessionInfo = sessionInfo

        val handler = backgroundHandler ?: run {
            startBackgroundThread()
            backgroundHandler!!
        }

        val primaryTag = if (isDualAttempt) "REAR" else activeMode.shortLabel.uppercase(Locale.US)
        val primary = CameraPipeline(
            cameraId = primaryCameraId,
            label = primaryTag,
            recordAudio = true,
            prefer720p = isDualAttempt,
            outputFile = primaryFile,
            isSecondary = false
        )
        primaryPipeline = primary

        primary.start(
            manager = manager,
            handler = handler,
            onStarted = {
                RecordingRepository.addDiagnostic(
                    EventLevel.INFO,
                    "Primary $primaryTag stream (#$primaryCameraId) recording to ${primaryFile.name}"
                )
                if (!isDualAttempt) {
                    markSessionRecording()
                } else {
                    // Open secondary front camera after primary stream is configured
                    startSecondaryDualStream(
                        manager = manager,
                        handler = handler,
                        frontId = frontId!!,
                        secondaryFile = secondaryFile!!
                    )
                }
            },
            onError = { errorCode, errorMessage ->
                handlePrimaryError(errorCode, errorMessage)
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun startSecondaryDualStream(
        manager: CameraManager,
        handler: Handler,
        frontId: String,
        secondaryFile: File
    ) {
        if (isStopping) return

        val secondary = CameraPipeline(
            cameraId = frontId,
            label = "FRONT",
            recordAudio = false, // Audio already captured on primary pipeline to avoid MIC contention
            prefer720p = true,
            outputFile = secondaryFile,
            isSecondary = true
        )
        secondaryPipeline = secondary

        secondary.start(
            manager = manager,
            handler = handler,
            onStarted = {
                RecordingRepository.addDiagnostic(
                    EventLevel.INFO,
                    "Secondary FRONT stream (#$frontId) recording concurrently to ${secondaryFile.name}"
                )
                markSessionRecording()
            },
            onError = { errorCode, errorMessage ->
                // Graceful fallback to primary rear camera without crashing or stopping primary audio/video
                val reason = if (errorCode == CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE ||
                    errorCode == CameraDevice.StateCallback.ERROR_CAMERA_IN_USE
                ) {
                    "Concurrent front camera rejected ($errorMessage). Gracefully continuing on primary rear camera."
                } else {
                    "Secondary front camera interrupted ($errorMessage). Continuing on primary rear camera."
                }
                Log.w(TAG, reason)
                RecordingRepository.addDiagnostic(EventLevel.WARN, reason)

                secondaryPipeline?.stopAndRelease(deleteIfEmpty = true)
                secondaryPipeline = null

                currentSessionInfo = currentSessionInfo?.copy(
                    activeMode = CameraSelectionMode.REAR_ONLY,
                    isDualActive = false,
                    secondaryFileName = null,
                    fallbackReason = reason,
                    statusMessage = "Rear camera active (Dual fallback)"
                )
                markSessionRecording()
            }
        )
    }

    private fun markSessionRecording() {
        val info = currentSessionInfo ?: return
        RecordingRepository.updateRecordingState(RecordingState.Recording(info))
        startElapsedTicker()
        updateNotification(info)
    }

    private fun handlePrimaryError(errorCode: Int, errorMessage: String) {
        if (isStopping) return

        Log.e(TAG, "Primary Camera2 error ($errorCode): $errorMessage")
        RecordingRepository.addDiagnostic(
            EventLevel.ERROR,
            "Primary camera interruption: $errorMessage"
        )

        // Safely finalize existing MP4 segment before attempting recovery
        primaryPipeline?.stopAndRelease(deleteIfEmpty = true)
        primaryPipeline = null
        secondaryPipeline?.stopAndRelease(deleteIfEmpty = true)
        secondaryPipeline = null

        val isFatalPermissionOrDisabled =
            errorCode == CameraDevice.StateCallback.ERROR_CAMERA_DISABLED

        if (!isFatalPermissionOrDisabled && recoveryCount < MAX_RECOVERY_ATTEMPTS) {
            recoveryCount += 1
            RecordingRepository.addDiagnostic(
                EventLevel.WARN,
                "Attempting automatic Camera2 recovery ($recoveryCount/$MAX_RECOVERY_ATTEMPTS)..."
            )
            currentSessionInfo = currentSessionInfo?.copy(
                recoveryCount = recoveryCount,
                statusMessage = "Recovering camera session ($recoveryCount/$MAX_RECOVERY_ATTEMPTS)..."
            )
            currentSessionInfo?.let {
                RecordingRepository.updateRecordingState(RecordingState.Recording(it))
            }

            recoveryJob?.cancel()
            recoveryJob = serviceScope.launch {
                delay(700L)
                if (!isStopping) {
                    launchCaptureSession(mode = requestedMode, isRecovery = true)
                }
            }
        } else {
            failSession(
                "Camera subsystem failed ($errorMessage). Saved available segments safely.",
                recoverable = true
            )
        }
    }

    private fun stopAndSaveRecording() {
        if (isStopping) return
        isStopping = true
        tickerJob?.cancel()
        recoveryJob?.cancel()

        RecordingRepository.updateRecordingState(RecordingState.Stopping)
        RecordingRepository.addDiagnostic(
            EventLevel.INFO,
            "Authenticated Stop & Save triggered. Finalizing MP4 containers..."
        )

        serviceScope.launch(Dispatchers.IO) {
            releasePipelines()
            RecordingRepository.refreshSavedClips(this@SafetyRecordingService)
            RecordingRepository.addDiagnostic(
                EventLevel.INFO,
                "Recording saved securely to SentinelCam Vault."
            )
            launch(Dispatchers.Main.immediate) {
                currentSessionInfo = null
                RecordingRepository.updateRecordingState(RecordingState.Idle)
                releaseWakeLock()
                ServiceCompat.stopForeground(this@SafetyRecordingService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun failSession(message: String, recoverable: Boolean) {
        isStopping = true
        tickerJob?.cancel()
        recoveryJob?.cancel()
        serviceScope.launch(Dispatchers.IO) {
            releasePipelines()
            RecordingRepository.refreshSavedClips(this@SafetyRecordingService)
            launch(Dispatchers.Main.immediate) {
                currentSessionInfo = null
                RecordingRepository.updateRecordingState(RecordingState.Error(message, recoverable))
                releaseWakeLock()
                ServiceCompat.stopForeground(this@SafetyRecordingService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun releasePipelines() {
        primaryPipeline?.stopAndRelease(deleteIfEmpty = true)
        primaryPipeline = null
        secondaryPipeline?.stopAndRelease(deleteIfEmpty = true)
        secondaryPipeline = null
    }

    private fun startElapsedTicker() {
        if (tickerJob?.isActive == true) return
        tickerJob = serviceScope.launch {
            while (isActive && !isStopping) {
                delay(1000L)
                val info = currentSessionInfo ?: continue
                val updated = info.copy(
                    elapsedSeconds = info.elapsedSeconds + 1L,
                    isWakeLockHeld = wakeLock?.isHeld == true
                )
                currentSessionInfo = updated
                RecordingRepository.updateRecordingState(RecordingState.Recording(updated))
                if (updated.elapsedSeconds % 5L == 0L) {
                    updateNotification(updated)
                }
            }
        }
    }

    private fun promoteToForeground(statusText: String) {
        val notification = buildNotification(statusText)
        val fgsType = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)
    }

    private fun updateNotification(info: ActiveSessionInfo) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val formatted = formatDuration(info.elapsedSeconds)
        val modeLabel = if (info.isDualActive) "Dual Front+Rear" else info.activeMode.shortLabel
        val text = "$modeLabel • $formatted • Unlock & authenticate in app to stop"
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(contentText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Intentionally NO "Stop" action in the notification to prevent lockscreen tampering.
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.notification_title_active))
            .setContentText(contentText)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_description)
                setShowBadge(false)
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SentinelCam::RecordingWakeLock"
        ).apply {
            setReferenceCounted(false)
            // 6-hour safety ceiling; released immediately on stop/destroy
            acquire(6 * 60 * 60 * 1000L)
        }
        RecordingRepository.addDiagnostic(
            EventLevel.INFO,
            "PARTIAL_WAKE_LOCK acquired to sustain screen-off capture."
        )
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
        wakeLock = null
    }

    private fun startBackgroundThread() {
        if (backgroundThread != null) return
        backgroundThread = HandlerThread("Camera2Background").apply { start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
    }

    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        runCatching { backgroundThread?.join(1000L) }
        backgroundThread = null
        backgroundHandler = null
    }

    private fun registerScreenReceiver() {
        if (screenReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        ContextCompat.registerReceiver(
            this,
            screenStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        screenReceiverRegistered = true
    }

    private fun unregisterScreenReceiver() {
        if (!screenReceiverRegistered) return
        runCatching { unregisterReceiver(screenStateReceiver) }
        screenReceiverRegistered = false
    }

    private fun hasRequiredRuntimePermissions(): Boolean {
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        return cam && mic
    }

    private fun formatDuration(totalSeconds: Long): String {
        val hrs = totalSeconds / 3600
        val mins = (totalSeconds % 3600) / 60
        val secs = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
    }

    /**
     * Encapsulates a single Camera2 -> MediaRecorder.getSurface() background capture pipeline.
     */
    private inner class CameraPipeline(
        private val cameraId: String,
        private val label: String,
        private val recordAudio: Boolean,
        private val prefer720p: Boolean,
        private val outputFile: File,
        private val isSecondary: Boolean
    ) {
        private var cameraDevice: CameraDevice? = null
        private var captureSession: CameraCaptureSession? = null
        private var mediaRecorder: MediaRecorder? = null

        @Volatile
        private var closed = false

        @Volatile
        private var recordingActive = false

        @SuppressLint("MissingPermission")
        fun start(
            manager: CameraManager,
            handler: Handler,
            onStarted: () -> Unit,
            onError: (Int, String) -> Unit
        ) {
            try {
                val recorder = createAndPrepareMediaRecorder(manager)
                mediaRecorder = recorder
                val surface = recorder.surface

                manager.openCamera(
                    cameraId,
                    object : CameraDevice.StateCallback() {
                        override fun onOpened(camera: CameraDevice) {
                            if (closed) {
                                camera.close()
                                return
                            }
                            cameraDevice = camera
                            createCaptureSession(camera, surface, handler, onStarted, onError)
                        }

                        override fun onDisconnected(camera: CameraDevice) {
                            Log.w(TAG, "Camera $label (#$cameraId) disconnected.")
                            camera.close()
                            cameraDevice = null
                            if (!closed) {
                                onError(CameraDevice.StateCallback.ERROR_CAMERA_DEVICE, "Camera disconnected")
                            }
                        }

                        override fun onError(camera: CameraDevice, error: Int) {
                            val name = cameraErrorName(error)
                            Log.e(TAG, "Camera $label (#$cameraId) onError: $name ($error)")
                            camera.close()
                            cameraDevice = null
                            if (!closed) {
                                onError(error, name)
                            }
                        }
                    },
                    handler
                )
            } catch (e: CameraAccessException) {
                val mappedError = when (e.reason) {
                    CameraAccessException.MAX_CAMERAS_IN_USE -> CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE
                    CameraAccessException.CAMERA_IN_USE -> CameraDevice.StateCallback.ERROR_CAMERA_IN_USE
                    CameraAccessException.CAMERA_DISABLED -> CameraDevice.StateCallback.ERROR_CAMERA_DISABLED
                    else -> CameraDevice.StateCallback.ERROR_CAMERA_DEVICE
                }
                Log.e(TAG, "CameraAccessException opening $label (#$cameraId): ${e.message}", e)
                stopAndRelease(deleteIfEmpty = true)
                onError(mappedError, cameraErrorName(mappedError))
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException opening $label (#$cameraId): ${e.message}", e)
                stopAndRelease(deleteIfEmpty = true)
                onError(CameraDevice.StateCallback.ERROR_CAMERA_DISABLED, "Camera permission denied")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize $label (#$cameraId): ${e.message}", e)
                stopAndRelease(deleteIfEmpty = true)
                onError(
                    CameraDevice.StateCallback.ERROR_CAMERA_DEVICE,
                    e.message ?: "MediaRecorder initialization error"
                )
            }
        }

        private fun createAndPrepareMediaRecorder(manager: CameraManager): MediaRecorder {
            val size = CameraCapabilityInspector.selectOptimalVideoSize(manager, cameraId, prefer720p)
            val orientation = CameraCapabilityInspector.getSensorOrientationHint(manager, cameraId)

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this@SafetyRecordingService)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            return recorder.apply {
                if (recordAudio) {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                }
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(outputFile.absolutePath)
                setVideoEncodingBitRate(if (prefer720p) 2_500_000 else 4_500_000)
                setVideoFrameRate(30)
                setVideoSize(size.width, size.height)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                if (recordAudio) {
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setAudioEncodingBitRate(128_000)
                    setAudioSamplingRate(44_100)
                }
                setOrientationHint(orientation)
                prepare()
            }
        }

        private fun createCaptureSession(
            camera: CameraDevice,
            recorderSurface: Surface,
            handler: Handler,
            onStarted: () -> Unit,
            onError: (Int, String) -> Unit
        ) {
            val sessionCallback = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (closed || cameraDevice == null) {
                        session.close()
                        return
                    }
                    captureSession = session
                    try {
                        val request = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                            addTarget(recorderSurface)
                            set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                            set(
                                CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                            )
                            set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                        }.build()

                        session.setRepeatingRequest(request, null, handler)
                        mediaRecorder?.start()
                        recordingActive = true
                        serviceScope.launch { onStarted() }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed starting repeating record request on $label", e)
                        stopAndRelease(deleteIfEmpty = true)
                        serviceScope.launch {
                            onError(
                                CameraDevice.StateCallback.ERROR_CAMERA_DEVICE,
                                e.message ?: "Capture session start error"
                            )
                        }
                    }
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Log.e(TAG, "CameraCaptureSession configuration failed on $label (#$cameraId)")
                    stopAndRelease(deleteIfEmpty = true)
                    val code = if (isSecondary) {
                        CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE
                    } else {
                        CameraDevice.StateCallback.ERROR_CAMERA_DEVICE
                    }
                    serviceScope.launch {
                        onError(code, "Session configuration failed on $label")
                    }
                }
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val executor = Executor { command -> handler.post(command) }
                    val config = SessionConfiguration(
                        SessionConfiguration.SESSION_REGULAR,
                        listOf(OutputConfiguration(recorderSurface)),
                        executor,
                        sessionCallback
                    )
                    camera.createCaptureSession(config)
                } else {
                    @Suppress("DEPRECATION")
                    camera.createCaptureSession(listOf(recorderSurface), sessionCallback, handler)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error creating capture session for $label", e)
                stopAndRelease(deleteIfEmpty = true)
                onError(
                    CameraDevice.StateCallback.ERROR_CAMERA_DEVICE,
                    e.message ?: "Capture session creation error"
                )
            }
        }

        fun stopAndRelease(deleteIfEmpty: Boolean) {
            closed = true
            runCatching { captureSession?.stopRepeating() }
            runCatching { captureSession?.abortCaptures() }
            runCatching { captureSession?.close() }
            captureSession = null

            runCatching { cameraDevice?.close() }
            cameraDevice = null

            if (recordingActive) {
                runCatching { mediaRecorder?.stop() }
                recordingActive = false
            }
            runCatching { mediaRecorder?.reset() }
            runCatching { mediaRecorder?.release() }
            mediaRecorder = null

            if (deleteIfEmpty && outputFile.exists() && outputFile.length() < 1024L) {
                runCatching { outputFile.delete() }
            }
        }

        private fun cameraErrorName(error: Int): String = when (error) {
            CameraDevice.StateCallback.ERROR_CAMERA_IN_USE -> "ERROR_CAMERA_IN_USE"
            CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE -> "ERROR_MAX_CAMERAS_IN_USE"
            CameraDevice.StateCallback.ERROR_CAMERA_DISABLED -> "ERROR_CAMERA_DISABLED"
            CameraDevice.StateCallback.ERROR_CAMERA_DEVICE -> "ERROR_CAMERA_DEVICE"
            CameraDevice.StateCallback.ERROR_CAMERA_SERVICE -> "ERROR_CAMERA_SERVICE"
            else -> "ERROR_UNKNOWN($error)"
        }
    }
}
