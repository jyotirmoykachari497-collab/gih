package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraFront
import androidx.compose.material.icons.filled.CameraRear
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ActiveSessionInfo
import com.example.model.CameraReadiness
import com.example.model.CameraSelectionMode
import com.example.model.PermissionStatus
import com.example.model.RecordingState
import com.example.ui.theme.LocalSentinelColors
import java.util.Locale

@Composable
fun GuardScreen(
    isWideScreen: Boolean,
    recordingState: RecordingState,
    cameraReadiness: CameraReadiness,
    selectedMode: CameraSelectionMode,
    permissionStatus: PermissionStatus,
    isStopAuthorized: Boolean,
    stopAuthCountdown: Int,
    statusBannerMessage: String?,
    onSelectMode: (CameraSelectionMode) -> Unit,
    onStartRecording: () -> Unit,
    onRequestPermissions: () -> Unit,
    onUnlockStopClick: () -> Unit,
    onStopAndSaveClick: () -> Unit,
    onEnableStealthClick: () -> Unit,
    onDismissBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = if (isWideScreen) 1040.dp else 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!statusBannerMessage.isNullOrBlank()) {
                AlertBannerCard(
                    message = statusBannerMessage,
                    isError = true,
                    onDismiss = onDismissBanner
                )
            }

            if (recordingState is RecordingState.Error) {
                AlertBannerCard(
                    message = recordingState.message,
                    isError = true,
                    onDismiss = null
                )
            }

            if (!permissionStatus.allRequiredGranted) {
                PermissionShieldCard(
                    permissionStatus = permissionStatus,
                    onGrantPermissions = onRequestPermissions
                )
            }

            if (isWideScreen) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.weight(1.1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        EmergencyActionPanel(
                            recordingState = recordingState,
                            cameraReadiness = cameraReadiness,
                            selectedMode = selectedMode,
                            isStopAuthorized = isStopAuthorized,
                            stopAuthCountdown = stopAuthCountdown,
                            onStartRecording = onStartRecording,
                            onUnlockStopClick = onUnlockStopClick,
                            onStopAndSaveClick = onStopAndSaveClick,
                            onEnableStealthClick = onEnableStealthClick
                        )
                    }
                    Column(
                        modifier = Modifier.weight(0.9f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CameraSelectorCard(
                            selectedMode = selectedMode,
                            cameraReadiness = cameraReadiness,
                            isLocked = recordingState !is RecordingState.Idle &&
                                recordingState !is RecordingState.Error,
                            onSelectMode = onSelectMode
                        )
                        HardwareReadinessCard(
                            cameraReadiness = cameraReadiness,
                            permissionStatus = permissionStatus
                        )
                    }
                }
            } else {
                EmergencyActionPanel(
                    recordingState = recordingState,
                    cameraReadiness = cameraReadiness,
                    selectedMode = selectedMode,
                    isStopAuthorized = isStopAuthorized,
                    stopAuthCountdown = stopAuthCountdown,
                    onStartRecording = onStartRecording,
                    onUnlockStopClick = onUnlockStopClick,
                    onStopAndSaveClick = onStopAndSaveClick,
                    onEnableStealthClick = onEnableStealthClick
                )

                CameraSelectorCard(
                    selectedMode = selectedMode,
                    cameraReadiness = cameraReadiness,
                    isLocked = recordingState !is RecordingState.Idle &&
                        recordingState !is RecordingState.Error,
                    onSelectMode = onSelectMode
                )

                HardwareReadinessCard(
                    cameraReadiness = cameraReadiness,
                    permissionStatus = permissionStatus
                )
            }
        }
    }
}

@Composable
private fun EmergencyActionPanel(
    recordingState: RecordingState,
    cameraReadiness: CameraReadiness,
    selectedMode: CameraSelectionMode,
    isStopAuthorized: Boolean,
    stopAuthCountdown: Int,
    onStartRecording: () -> Unit,
    onUnlockStopClick: () -> Unit,
    onStopAndSaveClick: () -> Unit,
    onEnableStealthClick: () -> Unit
) {
    val sentinelColors = LocalSentinelColors.current
    val isRecording = recordingState is RecordingState.Recording
    val isStarting = recordingState is RecordingState.Starting
    val isStopping = recordingState is RecordingState.Stopping

    val containerBrush = if (isRecording) {
        Brush.verticalGradient(
            listOf(
                sentinelColors.liveCrimsonContainer.copy(alpha = 0.72f),
                MaterialTheme.colorScheme.surface
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                MaterialTheme.colorScheme.surface
            )
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isRecording) sentinelColors.liveCrimson.copy(alpha = 0.6f)
            else MaterialTheme.colorScheme.outline
        ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(containerBrush)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (recordingState) {
                is RecordingState.Idle, is RecordingState.Error -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatusBadgePill(
                            text = if (cameraReadiness.isAnyCameraAvailable) "STANDBY • READY" else "NO CAMERA",
                            color = if (cameraReadiness.isAnyCameraAvailable) sentinelColors.ready else sentinelColors.warning
                        )
                        if (selectedMode == CameraSelectionMode.CONCURRENT_DUAL && !cameraReadiness.supportsConcurrentDual) {
                            StatusBadgePill(
                                text = "REAR FALLBACK",
                                color = sentinelColors.warning
                            )
                        }
                    }

                    Text(
                        text = "Covert Safety Capture",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Instant background video & audio capture. Continues uninterrupted if you turn off the screen or lock your phone.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onStartRecording,
                        enabled = cameraReadiness.isAnyCameraAvailable,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(72.dp)
                            .testTag("start_recording_button"),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = sentinelColors.liveCrimson,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RadioButtonChecked,
                            contentDescription = "Start emergency recording",
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = stringResource(R.string.action_start_emergency),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                is RecordingState.Starting -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            color = sentinelColors.liveCrimson,
                            strokeWidth = 3.dp
                        )
                        Spacer(Modifier.width(14.dp))
                        Text(
                            text = "Arming Camera2 & Foreground Service...",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                is RecordingState.Stopping -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            color = sentinelColors.ready,
                            strokeWidth = 3.dp
                        )
                        Spacer(Modifier.width(14.dp))
                        Text(
                            text = "Finalizing & sealing MP4 recording...",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                is RecordingState.Recording -> {
                    ActiveRecordingContent(
                        session = recordingState.session,
                        isStopAuthorized = isStopAuthorized,
                        stopAuthCountdown = stopAuthCountdown,
                        onUnlockStopClick = onUnlockStopClick,
                        onStopAndSaveClick = onStopAndSaveClick,
                        onEnableStealthClick = onEnableStealthClick
                    )
                }
            }

            if (isStarting || isStopping) {
                Text(
                    text = "Do not close while hardware pipeline transitions.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ActiveRecordingContent(
    session: ActiveSessionInfo,
    isStopAuthorized: Boolean,
    stopAuthCountdown: Int,
    onUnlockStopClick: () -> Unit,
    onStopAndSaveClick: () -> Unit,
    onEnableStealthClick: () -> Unit
) {
    val sentinelColors = LocalSentinelColors.current
    val pulseTransition = rememberInfiniteTransition(label = "rec_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .scale(pulseScale)
                    .alpha(pulseAlpha)
                    .clip(CircleShape)
                    .background(sentinelColors.liveCrimson)
            )
            Text(
                text = if (session.isDualActive) "REC • DUAL STREAM" else "REC • ${session.activeMode.shortLabel.uppercase(Locale.US)}",
                style = MaterialTheme.typography.labelLarge,
                color = sentinelColors.liveCrimson
            )
        }

        OutlinedButton(
            onClick = onEnableStealthClick,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("stealth_mode_button"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Icon(
                imageVector = Icons.Filled.VisibilityOff,
                contentDescription = "Enable stealth blackout screen",
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text("Stealth", style = MaterialTheme.typography.labelLarge)
        }
    }

    Text(
        text = formatElapsed(session.elapsedSeconds),
        style = MaterialTheme.typography.displayMedium,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag("recording_timer_text")
    )

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = session.statusMessage,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = buildString {
                append("File: ${session.primaryFileName}")
                if (session.secondaryFileName != null) {
                    append(" + ${session.secondaryFileName}")
                }
            },
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusBadgePill(
            text = if (session.isWakeLockHeld) "WAKELOCK ACTIVE" else "WAKELOCK PENDING",
            color = if (session.isWakeLockHeld) sentinelColors.ready else sentinelColors.warning
        )
        if (session.screenOffContinuityVerified) {
            StatusBadgePill(
                text = "SCREEN-OFF VERIFIED",
                color = sentinelColors.ready
            )
        }
        if (session.recoveryCount > 0) {
            StatusBadgePill(
                text = "RECOVERED x${session.recoveryCount}",
                color = sentinelColors.warning
            )
        }
    }

    if (!session.fallbackReason.isNullOrBlank()) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = sentinelColors.warningContainer,
            border = BorderStroke(1.dp, sentinelColors.warning.copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = "Camera fallback warning",
                    tint = sentinelColors.warning,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = session.fallbackReason,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }

    // Protected Biometric/Credential Stop Gate
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        border = BorderStroke(
            1.dp,
            if (isStopAuthorized) sentinelColors.liveCrimson else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (isStopAuthorized) Icons.Filled.LockOpen else Icons.Filled.Lock,
                    contentDescription = if (isStopAuthorized) "Stop control unlocked" else "Stop control locked",
                    tint = if (isStopAuthorized) sentinelColors.liveCrimson else sentinelColors.ready,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = if (isStopAuthorized) {
                        "Identity Verified — Armed for ${stopAuthCountdown}s"
                    } else {
                        "Tamper-Protected Stop Active"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Text(
                text = if (isStopAuthorized) {
                    "Press Stop & Save below to finalize and store your MP4 evidence."
                } else {
                    "Power button, screen lock, and notifications cannot stop this recording. Unlock your device and verify biometrics or PIN to arm Stop & Save."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            AnimatedVisibility(
                visible = !isStopAuthorized,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Button(
                    onClick = onUnlockStopClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("unlock_stop_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor = MaterialTheme.colorScheme.onSecondary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Fingerprint,
                        contentDescription = "Verify biometrics or PIN",
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.action_unlock_to_stop),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            AnimatedVisibility(
                visible = isStopAuthorized,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Button(
                    onClick = onStopAndSaveClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(62.dp)
                        .testTag("stop_recording_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = sentinelColors.liveCrimson,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Stop,
                        contentDescription = "Stop and save recording",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.action_stop_and_save),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun CameraSelectorCard(
    selectedMode: CameraSelectionMode,
    cameraReadiness: CameraReadiness,
    isLocked: Boolean,
    onSelectMode: (CameraSelectionMode) -> Unit
) {
    val sentinelColors = LocalSentinelColors.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cameraswitch,
                        contentDescription = "Camera capture mode",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Capture Configuration",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                if (isLocked) {
                    Text(
                        text = "LOCKED",
                        style = MaterialTheme.typography.labelSmall,
                        color = sentinelColors.warning
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CameraModeChip(
                    label = "Dual",
                    icon = Icons.Filled.Cameraswitch,
                    selected = selectedMode == CameraSelectionMode.CONCURRENT_DUAL,
                    enabled = !isLocked && cameraReadiness.isAnyCameraAvailable,
                    testTag = "camera_mode_dual",
                    onClick = { onSelectMode(CameraSelectionMode.CONCURRENT_DUAL) },
                    modifier = Modifier.weight(1f)
                )
                CameraModeChip(
                    label = "Rear",
                    icon = Icons.Filled.CameraRear,
                    selected = selectedMode == CameraSelectionMode.REAR_ONLY,
                    enabled = !isLocked && cameraReadiness.hasRearCamera,
                    testTag = "camera_mode_rear",
                    onClick = { onSelectMode(CameraSelectionMode.REAR_ONLY) },
                    modifier = Modifier.weight(1f)
                )
                CameraModeChip(
                    label = "Front",
                    icon = Icons.Filled.CameraFront,
                    selected = selectedMode == CameraSelectionMode.FRONT_ONLY,
                    enabled = !isLocked && cameraReadiness.hasFrontCamera,
                    testTag = "camera_mode_front",
                    onClick = { onSelectMode(CameraSelectionMode.FRONT_ONLY) },
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = when (selectedMode) {
                    CameraSelectionMode.CONCURRENT_DUAL -> if (cameraReadiness.supportsConcurrentDual) {
                        "Hardware supports concurrent Front + Rear streaming. Both streams save simultaneously."
                    } else {
                        "Hardware concurrent ISP not advertised; will attempt or gracefully fall back to primary Rear camera."
                    }
                    CameraSelectionMode.REAR_ONLY -> "Records high-definition 1080p rear video + AAC audio directly to MP4."
                    CameraSelectionMode.FRONT_ONLY -> "Records front-facing video + AAC audio directly to MP4."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CameraModeChip(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    enabled: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(48.dp)
            .testTag(testTag),
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = "$label camera mode",
                modifier = Modifier.size(18.dp)
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
            selectedLeadingIconColor = MaterialTheme.colorScheme.secondary
        )
    )
}

@Composable
private fun HardwareReadinessCard(
    cameraReadiness: CameraReadiness,
    permissionStatus: PermissionStatus
) {
    val sentinelColors = LocalSentinelColors.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = "System readiness indicators",
                    tint = sentinelColors.ready
                )
                Text(
                    text = "System Readiness",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            ReadinessRow(
                icon = Icons.Filled.CameraRear,
                title = "Rear Camera (Camera2)",
                statusText = if (cameraReadiness.hasRearCamera) "READY (#${cameraReadiness.rearCameraId})" else "UNAVAILABLE",
                isReady = cameraReadiness.hasRearCamera
            )
            ReadinessRow(
                icon = Icons.Filled.CameraFront,
                title = "Front Camera (Camera2)",
                statusText = if (cameraReadiness.hasFrontCamera) "READY (#${cameraReadiness.frontCameraId})" else "UNAVAILABLE",
                isReady = cameraReadiness.hasFrontCamera
            )
            ReadinessRow(
                icon = Icons.Filled.Cameraswitch,
                title = "Concurrent Dual ISP",
                statusText = if (cameraReadiness.supportsConcurrentDual) "SUPPORTED" else "REAR FALLBACK",
                isReady = cameraReadiness.supportsConcurrentDual,
                isWarningWhenFalse = true
            )
            ReadinessRow(
                icon = Icons.Filled.Mic,
                title = "Microphone & Camera Access",
                statusText = if (permissionStatus.cameraGranted && permissionStatus.audioGranted) "GRANTED" else "ACTION NEEDED",
                isReady = permissionStatus.cameraGranted && permissionStatus.audioGranted
            )
            ReadinessRow(
                icon = Icons.Filled.NotificationsActive,
                title = "Foreground Protection Notice",
                statusText = if (permissionStatus.notificationsGranted) "GRANTED" else "ACTION NEEDED",
                isReady = permissionStatus.notificationsGranted,
                isWarningWhenFalse = true
            )
        }
    }
}

@Composable
private fun ReadinessRow(
    icon: ImageVector,
    title: String,
    statusText: String,
    isReady: Boolean,
    isWarningWhenFalse: Boolean = false
) {
    val sentinelColors = LocalSentinelColors.current
    val statusColor = when {
        isReady -> sentinelColors.ready
        isWarningWhenFalse -> sentinelColors.warning
        else -> sentinelColors.liveCrimson
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (isReady) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                contentDescription = statusText,
                tint = statusColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelSmall,
                color = statusColor
            )
        }
    }
}

@Composable
private fun PermissionShieldCard(
    permissionStatus: PermissionStatus,
    onGrantPermissions: () -> Unit
) {
    val sentinelColors = LocalSentinelColors.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, sentinelColors.warning.copy(alpha = 0.6f)),
        colors = CardDefaults.cardColors(containerColor = sentinelColors.warningContainer.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = "Permissions required",
                    tint = sentinelColors.warning
                )
                Text(
                    text = "Permissions Needed for Background Capture",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            val missing = buildList {
                if (!permissionStatus.cameraGranted) add("Camera")
                if (!permissionStatus.audioGranted) add("Microphone")
                if (!permissionStatus.notificationsGranted) add("Notifications")
            }.joinToString(", ")
            Text(
                text = "Missing: $missing. Grant access so SentinelCam can record continuously while your screen is locked.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onGrantPermissions,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("grant_permissions_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = sentinelColors.warning,
                    contentColor = Color.Black
                )
            ) {
                Text(
                    text = stringResource(R.string.action_grant_permissions),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AlertBannerCard(
    message: String,
    isError: Boolean,
    onDismiss: (() -> Unit)?
) {
    val sentinelColors = LocalSentinelColors.current
    val accent = if (isError) sentinelColors.liveCrimson else sentinelColors.warning
    val bg = if (isError) sentinelColors.liveCrimsonContainer else sentinelColors.warningContainer

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = bg.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = "Alert",
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            if (onDismiss != null) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Text("Dismiss")
                }
            }
        }
    }
}

@Composable
private fun StatusBadgePill(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = color.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

private fun formatElapsed(totalSeconds: Long): String {
    val hrs = totalSeconds / 3600
    val mins = (totalSeconds % 3600) / 60
    val secs = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
}
