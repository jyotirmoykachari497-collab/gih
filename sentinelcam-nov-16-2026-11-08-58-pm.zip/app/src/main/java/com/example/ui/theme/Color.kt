package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Dark Palette (OLED-friendly obsidian + high-visibility signal accents)
val ObsidianBackground = Color(0xFF0A0D13)
val ObsidianSurface = Color(0xFF121824)
val ObsidianSurfaceVariant = Color(0xFF1A2233)
val ObsidianOutline = Color(0xFF2B364D)

val SignalCrimson = Color(0xFFFF3B30)
val SignalCrimsonDark = Color(0xFF4C1111)
val SignalCrimsonLight = Color(0xFFFFDAD6)

val SlateBlueAccent = Color(0xFF60A5FA)
val SlateBlueContainer = Color(0xFF172554)

val EmeraldReady = Color(0xFF10B981)
val EmeraldReadyContainer = Color(0xFF064E3B)

val AmberWarning = Color(0xFFF59E0B)
val AmberWarningContainer = Color(0xFF451A03)

val SlateTextPrimary = Color(0xFFF1F5F9)
val SlateTextSecondary = Color(0xFF94A3B8)

// Crisp Daylight Palette
val DaylightBackground = Color(0xFFF8FAFC)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFE2E8F0)
val DaylightOutline = Color(0xFFCBD5E1)
val DaylightTextPrimary = Color(0xFF0F172A)
val DaylightTextSecondary = Color(0xFF475569)
val DaylightCrimson = Color(0xFFDC2626)
val DaylightCrimsonContainer = Color(0xFFFEE2E2)
val DaylightEmerald = Color(0xFF059669)
val DaylightEmeraldContainer = Color(0xFFD1FAE5)
val DaylightAmber = Color(0xFFD97706)
val DaylightAmberContainer = Color(0xFFFEF3C7)
