package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class SentinelExtendedColors(
    val ready: Color,
    val readyContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val liveCrimson: Color,
    val liveCrimsonContainer: Color,
    val stealthSurface: Color
)

val LocalSentinelColors = staticCompositionLocalOf {
    SentinelExtendedColors(
        ready = EmeraldReady,
        readyContainer = EmeraldReadyContainer,
        warning = AmberWarning,
        warningContainer = AmberWarningContainer,
        liveCrimson = SignalCrimson,
        liveCrimsonContainer = SignalCrimsonDark,
        stealthSurface = Color.Black
    )
}

private val SentinelDarkColorScheme = darkColorScheme(
    primary = SignalCrimson,
    onPrimary = Color.White,
    primaryContainer = SignalCrimsonDark,
    onPrimaryContainer = SignalCrimsonLight,
    secondary = SlateBlueAccent,
    onSecondary = ObsidianBackground,
    secondaryContainer = SlateBlueContainer,
    onSecondaryContainer = SlateTextPrimary,
    tertiary = EmeraldReady,
    onTertiary = ObsidianBackground,
    background = ObsidianBackground,
    onBackground = SlateTextPrimary,
    surface = ObsidianSurface,
    onSurface = SlateTextPrimary,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = SlateTextSecondary,
    outline = ObsidianOutline,
    error = SignalCrimson,
    onError = Color.White,
    errorContainer = SignalCrimsonDark,
    onErrorContainer = SignalCrimsonLight
)

private val SentinelLightColorScheme = lightColorScheme(
    primary = DaylightCrimson,
    onPrimary = Color.White,
    primaryContainer = DaylightCrimsonContainer,
    onPrimaryContainer = Color(0xFF7F1D1D),
    secondary = Color(0xFF2563EB),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDBEAFE),
    onSecondaryContainer = Color(0xFF1E3A8A),
    tertiary = DaylightEmerald,
    onTertiary = Color.White,
    background = DaylightBackground,
    onBackground = DaylightTextPrimary,
    surface = DaylightSurface,
    onSurface = DaylightTextPrimary,
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = DaylightTextSecondary,
    outline = DaylightOutline,
    error = DaylightCrimson,
    onError = Color.White,
    errorContainer = DaylightCrimsonContainer,
    onErrorContainer = Color(0xFF7F1D1D)
)

@Composable
fun SentinelCamTheme(
    darkTheme: Boolean = true,
    useSystemTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val isDark = if (useSystemTheme) isSystemInDarkTheme() else darkTheme
    val colorScheme = if (isDark) SentinelDarkColorScheme else SentinelLightColorScheme
    val extendedColors = if (isDark) {
        SentinelExtendedColors(
            ready = EmeraldReady,
            readyContainer = EmeraldReadyContainer,
            warning = AmberWarning,
            warningContainer = AmberWarningContainer,
            liveCrimson = SignalCrimson,
            liveCrimsonContainer = SignalCrimsonDark,
            stealthSurface = Color.Black
        )
    } else {
        SentinelExtendedColors(
            ready = DaylightEmerald,
            readyContainer = DaylightEmeraldContainer,
            warning = DaylightAmber,
            warningContainer = DaylightAmberContainer,
            liveCrimson = DaylightCrimson,
            liveCrimsonContainer = DaylightCrimsonContainer,
            stealthSurface = Color(0xFF05070B)
        )
    }

    CompositionLocalProvider(LocalSentinelColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
