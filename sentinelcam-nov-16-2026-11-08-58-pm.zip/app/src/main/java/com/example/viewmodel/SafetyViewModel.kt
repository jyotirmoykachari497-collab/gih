package com.example.viewmodel

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.camera.CameraCapabilityInspector
import com.example.data.RecordingRepository
import com.example.model.CameraReadiness
import com.example.model.CameraSelectionMode
import com.example.model.DiagnosticEvent
import com.example.model.EventLevel
import com.example.model.PermissionStatus
import com.example.model.RecordedClip
import com.example.model.RecordingState
import com.example.service.SafetyRecordingService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class SafetyViewModel : ViewModel() {

    val recordingState: StateFlow<RecordingState> = RecordingRepository.recordingState
    val cameraReadiness: StateFlow<CameraReadiness> = RecordingRepository.cameraReadiness
    val diagnosticEvents: StateFlow<List<DiagnosticEvent>> = RecordingRepository.diagnosticEvents
    val savedClips: StateFlow<List<RecordedClip>> = RecordingRepository.savedClips
    val isStopAuthorized: StateFlow<Boolean> = RecordingRepository.isStopAuthorized

    private val _selectedMode = MutableStateFlow(CameraSelectionMode.CONCURRENT_DUAL)
    val selectedMode: StateFlow<CameraSelectionMode> = _selectedMode.asStateFlow()

    private val _permissionStatus = MutableStateFlow(PermissionStatus())
    val permissionStatus: StateFlow<PermissionStatus> = _permissionStatus.asStateFlow()

    private val _stealthModeEnabled = MutableStateFlow(false)
    val stealthModeEnabled: StateFlow<Boolean> = _stealthModeEnabled.asStateFlow()

    private val _stopAuthCountdown = MutableStateFlow(0)
    val stopAuthCountdown: StateFlow<Int> = _stopAuthCountdown.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    private var authCountdownJob: Job? = null
    private var initializedHardware = false

    fun refreshEnvironment(context: Context) {
        val readiness = CameraCapabilityInspector.inspect(context)
        RecordingRepository.updateCameraReadiness(readiness)

        if (!initializedHardware) {
            initializedHardware = true
            RecordingRepository.addDiagnostic(
                EventLevel.INFO,
                "Hardware check: ${readiness.hardwareSummary}"
            )
            // Default to Dual when supported, or Rear when only single stream is supported
            _selectedMode.value = if (readiness.supportsConcurrentDual) {
                CameraSelectionMode.CONCURRENT_DUAL
            } else if (readiness.hasRearCamera) {
                CameraSelectionMode.REAR_ONLY
            } else {
                CameraSelectionMode.FRONT_ONLY
            }
        }

        updatePermissions(context)
        viewModelScope.launch {
            RecordingRepository.refreshSavedClips(context)
        }
    }

    fun updatePermissions(context: Context) {
        val cam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        _permissionStatus.value = PermissionStatus(
            cameraGranted = cam,
            audioGranted = mic,
            notificationsGranted = notif
        )
    }

    fun requiredRuntimePermissions(): Array<String> {
        return buildList {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
    }

    fun selectCameraMode(mode: CameraSelectionMode) {
        if (recordingState.value is RecordingState.Recording ||
            recordingState.value is RecordingState.Starting
        ) {
            return
        }
        _selectedMode.value = mode
        RecordingRepository.addDiagnostic(
            EventLevel.INFO,
            "Camera mode set to ${mode.label}"
        )
    }

    fun startEmergencyRecording(context: Context) {
        updatePermissions(context)
        val perms = _permissionStatus.value
        if (!perms.cameraGranted || !perms.audioGranted) {
            _statusBannerMessage.value = "Camera and Microphone permissions are required before recording."
            return
        }
        _statusBannerMessage.value = null
        val intent = SafetyRecordingService.createStartIntent(context, _selectedMode.value)
        ContextCompat.startForegroundService(context, intent)
    }

    fun onAuthenticationSucceeded() {
        RecordingRepository.authorizeStop()
        _statusBannerMessage.value = null
        startStopAuthCountdown()
    }

    fun onAuthenticationError(message: String) {
        _statusBannerMessage.value = message
        RecordingRepository.addDiagnostic(EventLevel.WARN, "Stop verification failed: $message")
    }

    fun revokeStopUnlockOnBackground() {
        authCountdownJob?.cancel()
        _stopAuthCountdown.value = 0
        RecordingRepository.revokeStopAuthorization(
            "App moved to background/locked — Stop & Save re-locked."
        )
    }

    fun triggerAuthenticatedStopAndSave(context: Context) {
        if (!RecordingRepository.isStopAuthorized.value) {
            _statusBannerMessage.value = "Authenticate first to unlock Stop & Save."
            return
        }
        authCountdownJob?.cancel()
        _stopAuthCountdown.value = 0
        _stealthModeEnabled.value = false
        val intent = SafetyRecordingService.createAuthenticatedStopIntent(context)
        context.startService(intent)
    }

    fun toggleStealthMode(enabled: Boolean) {
        _stealthModeEnabled.value = enabled
    }

    fun dismissBanner() {
        _statusBannerMessage.value = null
    }

    fun deleteClip(context: Context, clip: RecordedClip) {
        viewModelScope.launch {
            RecordingRepository.deleteClip(context, clip)
        }
    }

    fun refreshClips(context: Context) {
        viewModelScope.launch {
            RecordingRepository.refreshSavedClips(context)
        }
    }

    private fun startStopAuthCountdown() {
        authCountdownJob?.cancel()
        authCountdownJob = viewModelScope.launch {
            for (sec in 15 downTo 1) {
                if (!isActive || !RecordingRepository.isStopAuthorized.value) return@launch
                _stopAuthCountdown.value = sec
                delay(1000L)
            }
            _stopAuthCountdown.value = 0
            RecordingRepository.revokeStopAuthorization(
                "15s authorization window expired — re-authenticate to Stop & Save."
            )
        }
    }
}
