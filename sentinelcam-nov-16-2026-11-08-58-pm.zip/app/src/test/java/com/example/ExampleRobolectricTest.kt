package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.RecordingRepository
import com.example.model.ActiveSessionInfo
import com.example.model.CameraSelectionMode
import com.example.model.RecordingState
import com.example.service.SafetyRecordingService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Before
    fun setUp() {
        RecordingRepository.updateRecordingState(RecordingState.Idle)
    }

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SentinelCam", appName)
    }

    @Test
    fun `stop authorization requires active recording and revokes on screen off`() {
        RecordingRepository.authorizeStop()
        assertFalse(RecordingRepository.isStopAuthorized.value)

        val session = ActiveSessionInfo(
            modeRequested = CameraSelectionMode.CONCURRENT_DUAL,
            activeMode = CameraSelectionMode.REAR_ONLY,
            isDualActive = false,
            fallbackReason = "Single ISP fallback",
            primaryFileName = "SafetyRec_20261116_093000.mp4"
        )
        RecordingRepository.updateRecordingState(RecordingState.Recording(session))
        assertFalse(RecordingRepository.isStopAuthorized.value)

        RecordingRepository.authorizeStop()
        assertTrue(RecordingRepository.isStopAuthorized.value)

        RecordingRepository.revokeStopAuthorization("Screen turned off")
        assertFalse(RecordingRepository.isStopAuthorized.value)
    }

    @Test
    fun `service blocks unauthenticated stop intent`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val session = ActiveSessionInfo(
            modeRequested = CameraSelectionMode.REAR_ONLY,
            activeMode = CameraSelectionMode.REAR_ONLY,
            isDualActive = false,
            primaryFileName = "SafetyRec_20261116_093001.mp4"
        )
        RecordingRepository.updateRecordingState(RecordingState.Recording(session))
        assertFalse(RecordingRepository.isStopAuthorized.value)

        val service = Robolectric.buildService(SafetyRecordingService::class.java).create().get()
        service.onStartCommand(SafetyRecordingService.createAuthenticatedStopIntent(context), 0, 1)

        // State must remain Recording because isStopAuthorized was false
        assertTrue(RecordingRepository.recordingState.value is RecordingState.Recording)
    }
}
